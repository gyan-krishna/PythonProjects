US States Data
==============
This repository contains some CSV files with information about US states and
territories. This is intended for demonstrating data merging and cleaning.
Data was scraped from the US Census Beaureau and from Wikipedia.